import tkinter as tk
from tkinter import messagebox
from geopy.geocoders import Nominatim
from timezonefinder import TimezoneFinder
from datetime import datetime
import requests
import pytz
import os  # For environment variables

root = tk.Tk()
root.title("Weather App")
root.geometry("900x500+300+200")
root.resizable(False, False)

# API Key (Use environment variable for security)
API_KEY = "9eb5d61c4f7fdef5aa5cadc89a8971bc" #os.environ.get("OPENWEATHER_API_KEY")
if not API_KEY:
    messagebox.showerror("Error", "API key not found. Please set the OPENWEATHER_API_KEY environment variable.")
    exit()

def get_weather():
    city = textfield.get()
    geolocator = Nominatim(user_agent="myweatherapp")

    try:
        location = geolocator.geocode(city)
        if location is None:
            messagebox.showerror("Error", "City not found!")
            return

        obj = TimezoneFinder()
        result = obj.timezone_at(lng=location.longitude, lat=location.latitude)
        home = pytz.timezone(result)
        local_time = datetime.now(home)
        current_time = local_time.strftime("%I:%M %p")
        clock_label.config(text=current_time)
        current_weather_label.config(text="CURRENT WEATHER")

        api = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
        response = requests.get(api)
        response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
        json_data = response.json()

        if "weather" not in json_data or "main" not in json_data:
            messagebox.showerror("Error", "Invalid response from weather API")
            return

        condition = json_data['weather'][0]['main']
        description = json_data['weather'][0]['description']
        temp = int(json_data['main']['temp'])
        pressure = json_data['main']['pressure']
        humidity = json_data['main']['humidity']
        wind = json_data['wind']['speed']

        temperature_label.config(text=f"{temp}°C")
        condition_label.config(text=f"{condition} | FEELS LIKE {temp}°C")
        wind_label.config(text=f"{wind} m/s")
        humidity_label.config(text=f"{humidity}%")
        description_label.config(text=description.capitalize())
        pressure_label.config(text=f"{pressure} hPa")

    except requests.exceptions.RequestException as e:
        messagebox.showerror("Error", f"Network error: {e}")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

# UI Setup
Search_image = tk.PhotoImage(file="search.png")
myimage = tk.Label(image=Search_image)
myimage.place(x=20, y=20)

textfield = tk.Entry(root, justify="center", width=17, font=("poppins", 25, "bold"), bg="#404040", border=0, fg="white")
textfield.place(x=50, y=40)
textfield.focus()

Search_icon = tk.PhotoImage(file="search_icon.png")
myimage_icon = tk.Button(image=Search_icon, borderwidth=0, cursor="hand2", bg="#404040", command=get_weather)
myimage_icon.place(x=400, y=34)

Logo_image = tk.PhotoImage(file="logo.png")
Logo = tk.Label(image=Logo_image)
Logo.place(x=150, y=100)

Frame_image = tk.PhotoImage(file="box.png")
frame_myimage = tk.Label(image=Frame_image)
frame_myimage.pack(padx=5, pady=5, side=tk.BOTTOM)

current_weather_label = tk.Label(root, font=("arial", 15, "bold"))
current_weather_label.place(x=30, y=100)

clock_label = tk.Label(root, font=("Helvetica", 20))
clock_label.place(x=30, y=130)

def create_bottom_label(text, x):
    label = tk.Label(root, text=text, font=("Helvetica", 15, "bold"), fg="white", bg="#1ab5ef")
    label.place(x=x, y=400)
    data_label = tk.Label(root, text="...", font=("arial", 20, "bold"), bg="#1ab5ef")
    data_label.place(x=x, y=430)
    return data_label

wind_label = create_bottom_label("WIND", 120)
humidity_label = create_bottom_label("HUMIDITY", 250)
description_label = create_bottom_label("DESCRIPTION", 430)
pressure_label = create_bottom_label("PRESSURE", 650)

temperature_label = tk.Label(font=("arial", 70, "bold"), fg="#ee666d")
temperature_label.place(x=400, y=150)
condition_label = tk.Label(font=("arial", 15, "bold"))
condition_label.place(x=400, y=250)

root.mainloop()